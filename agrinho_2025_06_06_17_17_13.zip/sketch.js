//Definindo variáveis globais 
let jardineiro;
let plantas = [];
let temperatura= 10;
let totalArvores = 0;

function setup() {
  createCanvas(600,400);
  jardineiro = new Jardineiro(width / 2, height - 50);
}
function draw() {
  // Usando map() para a cor de fundo de forma mais controlada
  let corFundo = lerpColor(color(217,112,26) , color(219,239,208),
    map(totalArvores,0,100,0,1));
  background(corFundo);
  mostrarInformacoes();
  temperatura+= 0,1; 
  jardineiro, atualizar();
  jardineiro, mostrar();
  
  // Verifica se o jogo acabou 
  verificaFimDeJogo();
  
  // Usando map() para aplicar o comportamento de árvores plantadas 
  plantas,map((arvore)=> arvore,mostrar());
  
}
// Função para mostrar as informaçãoes na tela 
function mostrarInformacoes () {
  textSize(26);
  fill(0);
  text("vamos plantar árvores para reduzir a temperatura?",10,30)
  textSize(14);
  fill('white');
  text("temperatura;" + temperatura,toFixed(2), 10 , 390);
  text("árvores plantadas;"+ totalArvores,460,390);
  text("para movimentar o personagen use as setas do teclado,",10,60);
  text("para plantar árvores use P ou espaço,",10,80);
}
// Função para verificar se o jogo acabou
function verificarFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemDeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}
//Função para atualizar a posição do jardineiro  atualizar () {
  if (keyIsdown(LEFT_ARROW)){
    this.x -=this.velocidade;
  if(keyIsdown(RIGHT_ARROW)){
   this.y += this.velocidade;
  }
  if (keyIsdown(UP_ARROW)){
    this.y -= this.velocidade;
  }
  if (keyIsdown(DOWN_ARROW)){
    this.y += this.velocidade;
  }
}
// Função para atualizar a posição do jardineiro atualizar() {
   if (keyIsdown(LEFT_ARROW)) {
     this.x -= this.velocidade;
   }
  if (keyIsDown(RIGHT_ARROW)){
    this.x +=this.velocidade;
  }
  if(keyIsDown(UP_ARROW)){
  this.y -= this.velocidade;
}
if (keyIsDown(DOWN_ARROW)) {
  this.y += this.velocidade;
}

// Função para criar e plantar uma árvore 
function keyPressed(){ 
  if (key === ''|| key === 'p'){
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
    plantas.push(arvore);
    totalArvores++;
    temperatura -=3;
    if(temperatura < 0)temperatura = 0;
  }
}